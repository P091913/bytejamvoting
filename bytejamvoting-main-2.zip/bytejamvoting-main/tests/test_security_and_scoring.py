import pytest

from bytejam.extensions import db
from bytejam.models import User, Vote
from bytejam.scoring import BAYES_PRIOR_WEIGHT, compute_rankings
from bytejam.security import safe_next_url

from .conftest import make_app


# ---------- IP allowlist ----------

@pytest.fixture
def restricted_client():
    app = make_app(ALLOW_ALL=False, ALLOWED_CONN=["10.1.2.3", "192.168.", "172.16.0.0/12"])
    return app.test_client()


@pytest.mark.parametrize("ip, allowed", [
    ("10.1.2.3", True),        # exact
    ("192.168.5.5", True),     # prefix
    ("172.20.1.1", True),      # CIDR
    ("8.8.8.8", False),
    ("10.1.2.4", False),
])
def test_ip_allowlist(restricted_client, ip, allowed):
    resp = restricted_client.get("/create", environ_base={"REMOTE_ADDR": ip})
    assert (resp.status_code != 403) == allowed


def test_admin_login_reachable_from_any_ip(restricted_client):
    assert restricted_client.get("/admin-login", environ_base={"REMOTE_ADDR": "8.8.8.8"}).status_code == 200


def test_static_reachable_from_any_ip(restricted_client):
    assert restricted_client.get("/static/css/styles.css", environ_base={"REMOTE_ADDR": "8.8.8.8"}).status_code == 200


def test_forwarded_for_cannot_be_spoofed_behind_one_proxy():
    app = make_app(ALLOW_ALL=False, ALLOWED_CONN=["10.1.2.3"], TRUSTED_PROXIES=1)
    client = app.test_client()
    # Client claims to be 10.1.2.3; the proxy appends the real address (8.8.8.8).
    resp = client.get("/create", headers={"X-Forwarded-For": "10.1.2.3, 8.8.8.8"})
    assert resp.status_code == 403
    resp = client.get("/create", headers={"X-Forwarded-For": "10.1.2.3"})
    assert resp.status_code == 200


# ---------- CSRF ----------

def test_csrf_blocks_forms_without_token():
    app = make_app(WTF_CSRF_ENABLED=True)
    resp = app.test_client().post("/register_user", data={"user_type": "2", "first_name": "A", "last_name": "B"})
    assert resp.status_code == 302
    with app.app_context():
        assert db.session.scalar(db.select(db.func.count()).select_from(User)) == 0


# ---------- Redirect safety ----------

@pytest.mark.parametrize("target, expected", [
    ("/admin", "/admin"),
    (None, "/fallback"),
    ("https://evil.example/", "/fallback"),
    ("//evil.example", "/fallback"),
    ("admin", "/fallback"),
])
def test_safe_next_url(target, expected):
    assert safe_next_url(target, "/fallback") == expected


# ---------- Scoring ----------

def test_rankings_bayesian_average(app, roster):
    # Two voters give Hawkeyes 10 total each; one voter gives Byte Me 4 total.
    for user, team, score in [
        ("rep", "ihcc", 10), ("bits_student", "ihcc", 10), ("bits_coach", "bytes", 4),
    ]:
        db.session.add(Vote(team_id=roster[team].id, user_id=roster[user].id, category="Creativity", score=score))
    db.session.commit()

    rankings = compute_rankings()
    overall_mean = 24 / 3
    m = BAYES_PRIOR_WEIGHT

    assert [r.team_name for r in rankings] == ["Hawkeyes", "Byte Me"]
    assert [r.rank for r in rankings] == [1, 2]
    assert rankings[0].raw_average == 10 and rankings[0].vote_count == 2
    assert rankings[0].adjusted_score == round((2 * 10 + m * overall_mean) / (2 + m), 4)
    assert rankings[1].adjusted_score == round((1 * 4 + m * overall_mean) / (1 + m), 4)


def test_rankings_empty(app):
    assert compute_rankings() == []


def test_results_tab_shows_rankings(admin_client, roster):
    db.session.add(Vote(team_id=roster["ihcc"].id, user_id=roster["rep"].id, category="Creativity", score=5))
    db.session.commit()
    html = admin_client.get("/admin").data
    assert b"No votes yet." not in html


def test_public_leaderboard_toggle(roster, open_window, client, app):
    from .conftest import login_as
    login_as(client, roster["rep"])
    assert b"Leaderboard" not in client.get("/").data
    app.config["PUBLIC_LEADERBOARD"] = True
    assert b"Leaderboard" in client.get("/").data
