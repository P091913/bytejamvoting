from datetime import datetime, timedelta

import pytest

from bytejam import create_app
from bytejam.extensions import db
from bytejam.models import Company, Team, User, VotingSettings

ADMIN_USER = "admin"
ADMIN_PASS = "secret"

TEST_CONFIG = {
    "TESTING": True,
    "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
    "WTF_CSRF_ENABLED": False,
    "ALLOW_ALL": True,
    "ALLOWED_CONN": ["127.0.0.1"],
    "TRUSTED_PROXIES": 0,
    "ADMIN_USERNAME": ADMIN_USER,
    "ADMIN_PASSWORD": ADMIN_PASS,
    "VOTING_TIMEZONE": None,
    "PUBLIC_LEADERBOARD": False,
}


def make_app(**overrides):
    app = create_app({**TEST_CONFIG, **overrides})
    with app.app_context():
        db.create_all()
    return app


@pytest.fixture
def app():
    app = make_app()
    with app.app_context():
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def admin_client(client):
    client.post("/admin-login", data={"username": ADMIN_USER, "password": ADMIN_PASS})
    return client


@pytest.fixture
def open_window(app):
    now = datetime.now()
    db.session.add(VotingSettings(voting_start=now - timedelta(hours=1), voting_end=now + timedelta(hours=1)))
    db.session.commit()


@pytest.fixture
def roster(app):
    """A small event: one team per division, a company, and one of each kind of member."""
    bits = Team(name="Bit Busters", division="Bits")
    bytes_ = Team(name="Byte Me", division="Bytes")
    ihcc = Team(name="Hawkeyes", division="IHCC")
    acme = Company(name="Acme", pin="1111")
    db.session.add_all([bits, bytes_, ihcc, acme])
    db.session.flush()

    people = {
        "rep": User(role="company", first_name="Rita", last_name="Rep", pin="1111", company_id=acme.id, ip_address=""),
        "bits_coach": User(role="coach", first_name="Cal", last_name="Coach", pin="2222", team_id=bits.id, ip_address=""),
        "bits_student": User(role="student", first_name="Sam", last_name="Bits", pin="3333", team_id=bits.id, ip_address=""),
        "ihcc_student": User(role="student", first_name="Ivy", last_name="Hawk", pin="4444", team_id=ihcc.id, ip_address=""),
    }
    db.session.add_all(people.values())
    db.session.commit()
    return {"bits": bits, "bytes": bytes_, "ihcc": ihcc, "acme": acme, **people}


def login_as(client, user):
    with client.session_transaction() as session:
        session["user_id"] = user.id
