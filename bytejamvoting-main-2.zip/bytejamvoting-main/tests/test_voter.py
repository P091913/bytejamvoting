from datetime import datetime, timedelta

from bytejam.extensions import db
from bytejam.models import User, Vote, VotingSettings

from .conftest import login_as

STUDENT_BALLOT = {"amazement": "5", "theme": "4", "performance": "3"}
STANDARD_BALLOT = {"creativity": "5", "visualdesign": "4", "professionalism": "3", "communication": "2", "performance": "1"}


# ---------- Sign in ----------

def test_signup_page_renders_with_fresh_pin(client):
    resp = client.get("/create")
    assert resp.status_code == 200
    assert b'name="pin"' in resp.data


def test_guest_registration_creates_guest_and_logs_in(client):
    resp = client.post("/register_user", data={"user_type": "2", "first_name": "Gus", "last_name": "Guest", "pin": "1234"})
    assert resp.headers["Location"] == "/"
    guest = db.session.scalars(db.select(User).filter_by(first_name="Gus")).one()
    assert guest.role == "guest" and guest.pin == "1234"
    with client.session_transaction() as session:
        assert session["user_id"] == guest.id


def test_guest_registration_rejects_bad_pin(client):
    resp = client.post("/register_user", data={"user_type": "2", "first_name": "Gus", "last_name": "Guest", "pin": "12ab"})
    assert resp.headers["Location"] == "/create"
    assert db.session.scalars(db.select(User)).first() is None


def test_member_login_with_company_pin(client, roster):
    resp = client.post("/register_user", data={"user_type": "1", "m_first_name": "Rita", "m_last_name": "Rep", "company_pin": "1111"})
    assert resp.headers["Location"] == "/"
    with client.session_transaction() as session:
        assert session["user_id"] == roster["rep"].id


def test_member_login_with_personal_pin(client, roster):
    client.post("/register_user", data={"user_type": "1", "m_first_name": "Sam", "m_last_name": "Bits", "company_pin": "3333"})
    with client.session_transaction() as session:
        assert session["user_id"] == roster["bits_student"].id


def test_member_login_unknown_user(client, roster):
    resp = client.post("/register_user", data={"user_type": "1", "m_first_name": "No", "m_last_name": "Body", "company_pin": "9999"}, follow_redirects=True)
    assert b"User not found" in resp.data


# ---------- Dashboard ----------

def test_dashboard_without_settings_redirects_to_not_allowed(client):
    resp = client.get("/", follow_redirects=True)
    assert b"Voting is not allowed at this time." in resp.data
    assert b"Voting settings have not been configured yet." in resp.data


def test_dashboard_outside_window_redirects(client, roster):
    past = datetime.now() - timedelta(days=2)
    db.session.add(VotingSettings(voting_start=past, voting_end=past + timedelta(hours=1)))
    db.session.commit()
    login_as(client, roster["rep"])
    assert client.get("/").headers["Location"] == "/not_allowed"


def test_dashboard_requires_login(client, open_window):
    assert client.get("/").headers["Location"] == "/create"


def test_dashboard_session_for_deleted_user_is_logged_out(client, open_window):
    with client.session_transaction() as session:
        session["user_id"] = 999
    assert client.get("/").headers["Location"] == "/create"


def test_company_rep_sees_only_ihcc(client, roster, open_window):
    login_as(client, roster["rep"])
    html = client.get("/").data
    assert b"Hawkeyes" in html and b"Bit Busters" not in html and b"Byte Me" not in html


def test_bits_coach_sees_only_bytes(client, roster, open_window):
    login_as(client, roster["bits_coach"])
    html = client.get("/").data
    assert b"Byte Me" in html and b"Bit Busters" not in html and b"Hawkeyes" not in html


def test_ihcc_student_sees_bits_and_bytes(client, roster, open_window):
    login_as(client, roster["ihcc_student"])
    html = client.get("/").data
    assert b"Byte Me" in html and b"Bit Busters" in html and b"Hawkeyes" not in html


def test_student_gets_student_categories(client, roster, open_window):
    login_as(client, roster["bits_student"])
    html = client.get("/").data
    assert b'name="amazement"' in html and b'name="creativity"' not in html


# ---------- Voting ----------

def _votes_for(user):
    return {v.category: v.score for v in db.session.scalars(db.select(Vote).filter_by(user_id=user.id))}


def test_student_can_vote(client, roster, open_window):
    login_as(client, roster["bits_student"])
    resp = client.post("/submit_vote", data={"team": "Byte Me", **STUDENT_BALLOT}, follow_redirects=True)
    assert b"has been submitted" in resp.data
    assert _votes_for(roster["bits_student"]) == {"Amazement": 5, "Theme": 4, "Performance": 3}


def test_company_rep_can_vote(client, roster, open_window):
    login_as(client, roster["rep"])
    client.post("/submit_vote", data={"team": "Hawkeyes", **STANDARD_BALLOT})
    assert _votes_for(roster["rep"]) == {
        "Creativity": 5, "Visual Design": 4, "Professionalism": 3, "Communication": 2, "Performance": 1,
    }


def test_cannot_vote_twice_for_same_team(client, roster, open_window):
    login_as(client, roster["rep"])
    client.post("/submit_vote", data={"team": "Hawkeyes", **STANDARD_BALLOT})
    resp = client.post("/submit_vote", data={"team": "Hawkeyes", **STANDARD_BALLOT}, follow_redirects=True)
    assert b"already voted" in resp.data
    assert len(_votes_for(roster["rep"])) == 5


def test_voted_team_shows_as_voted(client, roster, open_window):
    login_as(client, roster["rep"])
    client.post("/submit_vote", data={"team": "Hawkeyes", **STANDARD_BALLOT})
    assert "Voted ✓".encode() in client.get("/").data


def test_rejects_out_of_range_score(client, roster, open_window):
    login_as(client, roster["rep"])
    resp = client.post("/submit_vote", data={"team": "Hawkeyes", **STANDARD_BALLOT, "creativity": "9"}, follow_redirects=True)
    assert b"between 0 and 5" in resp.data
    assert _votes_for(roster["rep"]) == {}


def test_rejects_missing_score(client, roster, open_window):
    login_as(client, roster["bits_student"])
    resp = client.post("/submit_vote", data={"team": "Byte Me", "amazement": "3"}, follow_redirects=True)
    assert b"All score fields are required." in resp.data


def test_rejects_vote_outside_allowed_division(client, roster, open_window):
    login_as(client, roster["rep"])
    resp = client.post("/submit_vote", data={"team": "Byte Me", **STANDARD_BALLOT}, follow_redirects=True)
    assert b"can&#39;t vote for teams in the Bytes division" in resp.data


def test_rejects_unknown_team(client, roster, open_window):
    login_as(client, roster["rep"])
    resp = client.post("/submit_vote", data={"team": "Nope", **STANDARD_BALLOT}, follow_redirects=True)
    assert b"Invalid team name." in resp.data


def test_rejects_vote_when_window_closed(client, roster):
    login_as(client, roster["rep"])
    client.post("/submit_vote", data={"team": "Hawkeyes", **STANDARD_BALLOT})
    assert _votes_for(roster["rep"]) == {}


def test_vote_requires_login(client):
    assert client.post("/submit_vote", data={"team": "x"}).headers["Location"] == "/create"
