from bytejam.extensions import db
from bytejam.models import Company, Team, User, Vote, VotingSettings

from .conftest import ADMIN_PASS, ADMIN_USER


def _count(model):
    return db.session.scalar(db.select(db.func.count()).select_from(model))


def _submit(client, **data):
    return client.post("/submit", data=data, follow_redirects=True)


# ---------- Auth ----------

def test_admin_requires_login(client):
    resp = client.get("/admin")
    assert resp.headers["Location"].startswith("/admin-login")


def test_admin_login_and_logout(client):
    resp = client.post("/admin-login", data={"username": ADMIN_USER, "password": ADMIN_PASS})
    assert resp.headers["Location"] == "/admin"
    assert client.get("/admin").status_code == 200
    client.get("/admin-logout")
    assert client.get("/admin").status_code == 302


def test_admin_login_wrong_password(client):
    resp = client.post("/admin-login", data={"username": ADMIN_USER, "password": "nope"})
    assert resp.status_code == 200
    assert b"Invalid admin credentials." in resp.data


def test_admin_login_ignores_offsite_next(client):
    resp = client.post("/admin-login?next=https://evil.example", data={"username": ADMIN_USER, "password": ADMIN_PASS})
    assert resp.headers["Location"] == "/admin"


def test_admin_login_follows_local_next(client):
    resp = client.post("/admin-login?next=/admin", data={"username": ADMIN_USER, "password": ADMIN_PASS})
    assert resp.headers["Location"] == "/admin"


def test_admin_actions_require_login(client):
    client.post("/submit", data={"type": "company", "action": "add", "company_name": "Acme"})
    assert _count(Company) == 0


# ---------- Panel ----------

def test_panel_renders_everything(admin_client, roster):
    html = admin_client.get("/admin").data
    for text in (b"Acme", b"1111", b"Rita Rep", b"Bit Busters", b"Cal Coach", b"Sam Bits", b"Hawkeyes"):
        assert text in html


# ---------- Companies ----------

def test_add_company_generates_pin(admin_client):
    resp = _submit(admin_client, type="company", action="add", company_name="Globex")
    assert b"Company &#39;Globex&#39; added successfully!" in resp.data
    company = db.session.scalars(db.select(Company)).one()
    assert company.pin.isdigit() and len(company.pin) == 4


def test_add_duplicate_company(admin_client, roster):
    resp = _submit(admin_client, type="company", action="add", company_name="Acme")
    assert b"already exists" in resp.data
    assert _count(Company) == 1


def test_add_company_member_uses_company_pin(admin_client, roster):
    _submit(admin_client, type="company", action="add_member", company_id=roster["acme"].id, first_name="New", last_name="Hire")
    user = db.session.scalars(db.select(User).filter_by(first_name="New")).one()
    assert user.role == "company" and user.pin == "1111" and user.company_id == roster["acme"].id


def test_remove_company_cascades_to_members_and_votes(admin_client, roster):
    db.session.add(Vote(team_id=roster["ihcc"].id, user_id=roster["rep"].id, category="Creativity", score=5))
    db.session.commit()
    _submit(admin_client, type="company", action="remove", company_id=roster["acme"].id)
    assert _count(Company) == 0
    assert db.session.get(User, roster["rep"].id) is None
    assert _count(Vote) == 0


def test_remove_company_member(admin_client, roster):
    _submit(admin_client, type="company", action="remove_member", user_id=roster["rep"].id)
    assert db.session.get(User, roster["rep"].id) is None


# ---------- Teams ----------

def test_add_team(admin_client):
    _submit(admin_client, type="team", action="add", team_name="New Team", division="Bytes")
    team = db.session.scalars(db.select(Team)).one()
    assert team.name == "New Team" and team.division == "Bytes"


def test_add_team_rejects_bad_division(admin_client):
    resp = _submit(admin_client, type="team", action="add", team_name="New Team", division="Kilobytes")
    assert b"Unknown division" in resp.data
    assert _count(Team) == 0


def test_add_team_member_shows_generated_pin(admin_client, roster):
    resp = _submit(admin_client, type="team", action="add_member", team_id=roster["bytes"].id,
                   first_name="Nia", last_name="New", role="coach")
    user = db.session.scalars(db.select(User).filter_by(first_name="Nia")).one()
    assert user.role == "coach" and user.team_id == roster["bytes"].id
    assert f"with PIN {user.pin}".encode() in resp.data


def test_add_team_member_unknown_role_defaults_to_student(admin_client, roster):
    _submit(admin_client, type="team", action="add_member", team_id=roster["bytes"].id,
            first_name="Nia", last_name="New", role="wizard")
    assert db.session.scalars(db.select(User).filter_by(first_name="Nia")).one().role == "student"


def test_remove_team_cascades(admin_client, roster):
    db.session.add(Vote(team_id=roster["bits"].id, user_id=roster["rep"].id, category="Creativity", score=5))
    db.session.commit()
    _submit(admin_client, type="team", action="remove", team_id=roster["bits"].id)
    assert db.session.get(Team, roster["bits"].id) is None
    assert db.session.get(User, roster["bits_coach"].id) is None
    assert _count(Vote) == 0
    assert db.session.get(User, roster["rep"].id) is not None


def test_remove_team_member(admin_client, roster):
    _submit(admin_client, type="team", action="remove_member", user_id=roster["bits_student"].id)
    assert db.session.get(User, roster["bits_student"].id) is None


def test_unknown_admin_action(admin_client):
    resp = _submit(admin_client, type="team", action="explode")
    assert b"Unknown admin action." in resp.data


# ---------- Voting window ----------

def test_save_voting_window(admin_client):
    resp = admin_client.post("/save_voting_settings", data={"voting_start": "2026-04-01T09:00", "voting_end": "2026-04-01T17:00"}, follow_redirects=True)
    assert b"Voting window saved." in resp.data
    assert _count(VotingSettings) == 1


def test_save_voting_window_rejects_backwards_range(admin_client):
    resp = admin_client.post("/save_voting_settings", data={"voting_start": "2026-04-01T17:00", "voting_end": "2026-04-01T09:00"}, follow_redirects=True)
    assert b"Voting start must be before voting end." in resp.data
    assert _count(VotingSettings) == 0


def test_save_voting_window_rejects_bad_format(admin_client):
    resp = admin_client.post("/save_voting_settings", data={"voting_start": "tomorrow", "voting_end": "later"}, follow_redirects=True)
    assert b"Invalid date format." in resp.data


# ---------- Clear data ----------

def _add_vote(roster):
    db.session.add(Vote(team_id=roster["ihcc"].id, user_id=roster["rep"].id, category="Creativity", score=5))
    db.session.commit()


def test_clear_votes_only(admin_client, roster):
    _add_vote(roster)
    admin_client.post("/delete_data", data={"delete_votes": "on"})
    assert _count(Vote) == 0 and _count(User) == 4 and _count(Team) == 3


def test_clear_users_also_clears_votes(admin_client, roster):
    _add_vote(roster)
    admin_client.post("/delete_data", data={"delete_users": "on"})
    assert _count(Vote) == 0 and _count(User) == 0 and _count(Team) == 3 and _count(Company) == 1


def test_clear_companies_keeps_team_members(admin_client, roster):
    _add_vote(roster)
    admin_client.post("/delete_data", data={"delete_companies": "on"})
    assert _count(Company) == 0 and _count(Vote) == 0
    assert _count(User) == 3  # the company rep is gone, team members remain


def test_clear_teams(admin_client, roster):
    admin_client.post("/delete_data", data={"delete_teams": "on"})
    assert _count(Team) == 0 and _count(User) == 1  # only the company rep remains


def test_clear_nothing_selected(admin_client, roster):
    resp = admin_client.post("/delete_data", data={}, follow_redirects=True)
    assert b"Select at least one" in resp.data
