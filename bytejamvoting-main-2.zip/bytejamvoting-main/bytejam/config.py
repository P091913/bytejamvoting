"""Application configuration, read from environment variables (or a local .env file)."""
import os
import secrets

from dotenv import load_dotenv

load_dotenv()


def _env_bool(name: str, default: bool = False) -> bool:
    return os.environ.get(name, str(default)).strip().lower() in ("1", "true", "yes")


def _env_list(name: str, default: str = "") -> list[str]:
    return [item.strip() for item in os.environ.get(name, default).split(",") if item.strip()]


def _database_url() -> str | None:
    url = os.environ.get("DATABASE_URL")
    # Render/Heroku hand out "postgres://" URLs, which SQLAlchemy 2.x no longer accepts.
    if url and url.startswith("postgres://"):
        url = "postgresql://" + url[len("postgres://"):]
    return url


class Config:
    # A random fallback works for a single dev process, but sessions won't survive restarts
    # or be shared between gunicorn workers. Always set FLASK_SECRET_KEY in production.
    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32)
    SECRET_KEY_FROM_ENV = bool(os.environ.get("FLASK_SECRET_KEY"))

    SQLALCHEMY_DATABASE_URI = _database_url()
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
    ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD")  # admin login is disabled when unset

    # Comma-separated client IPs / prefixes / CIDR ranges allowed to reach the app.
    ALLOWED_CONN = _env_list("ALLOWED_CONN", "127.0.0.1")
    # Skip the IP allowlist entirely (local development).
    ALLOW_ALL = _env_bool("ALLOW_ALL")
    # Number of reverse proxies in front of the app (Render = 1). Used to read the real client IP.
    TRUSTED_PROXIES = int(os.environ.get("TRUSTED_PROXIES", "1"))

    # IANA timezone the admin enters voting windows in, e.g. "America/Chicago".
    # Unset = the server's local time.
    VOTING_TIMEZONE = os.environ.get("VOTING_TIMEZONE") or None

    # Show the live leaderboard to voters on the dashboard.
    PUBLIC_LEADERBOARD = _env_bool("PUBLIC_LEADERBOARD")

    DEBUG = _env_bool("FLASK_DEBUG")
