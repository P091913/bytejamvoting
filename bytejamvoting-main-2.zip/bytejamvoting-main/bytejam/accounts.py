"""Voter sign-in: returning members (students, coaches, company reps) and new guests."""
from flask import session

from .extensions import db
from .models import Company, User
from .pins import is_valid_pin

SESSION_USER_KEY = "user_id"


class AccountError(Exception):
    """Sign-in failed; the message is safe to show to the voter."""


def find_member(first_name: str, last_name: str, pin: str) -> User:
    """Look up an existing member by name plus either their company's PIN or their own PIN."""
    if not (first_name and last_name and pin):
        raise AccountError("Name and company pin are required.")

    by_name = db.select(User).filter_by(first_name=first_name, last_name=last_name)

    company = db.session.scalars(db.select(Company).filter_by(pin=pin)).first()
    user = None
    if company:
        user = db.session.scalars(by_name.filter_by(company_id=company.id)).first()
    if not user:
        # Team members log in with their personal PIN and have no company.
        user = db.session.scalars(by_name.filter_by(pin=pin)).first()

    if not user:
        raise AccountError("User not found. If you should be there, ask an admin to add you.")
    return user


def register_guest(first_name: str, last_name: str, pin: str, ip_address: str) -> User:
    if not (first_name and last_name):
        raise AccountError("First and last name are required for guest registration.")
    if pin and not is_valid_pin(pin):
        raise AccountError("Invalid PIN format; must be 4 digits.")

    guest = User(role="guest", first_name=first_name, last_name=last_name, pin=pin or None, ip_address=ip_address)
    db.session.add(guest)
    db.session.commit()
    return guest


def log_in(user: User) -> None:
    session[SESSION_USER_KEY] = user.id


def current_user() -> User | None:
    user_id = session.get(SESSION_USER_KEY)
    if user_id is None:
        return None
    user = db.session.get(User, user_id)
    if user is None:
        # The account was deleted by an admin since this session started.
        session.pop(SESSION_USER_KEY, None)
    return user
