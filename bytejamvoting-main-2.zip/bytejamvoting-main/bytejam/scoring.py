"""Team rankings using a Bayesian average, so teams with few votes aren't over- or under-rated."""
from dataclasses import dataclass

from sqlalchemy import func

from .extensions import db
from .models import Team, Vote

# How many "average" votes every team is assumed to start with. Higher = more smoothing.
BAYES_PRIOR_WEIGHT = 10


@dataclass
class TeamRanking:
    rank: int
    team_id: int
    team_name: str
    adjusted_score: float
    raw_average: float
    vote_count: int


def compute_rankings() -> list[TeamRanking]:
    """Rank every team that has received votes.

    A team's raw average is its total score divided by the number of distinct voters
    (i.e. the average of each voter's summed category scores). That average is then pulled
    towards the overall mean in proportion to how few voters the team has.
    """
    rows = db.session.execute(
        db.select(
            Vote.team_id,
            Team.name.label("team_name"),
            func.sum(Vote.score).label("total_score"),
            func.count(func.distinct(Vote.user_id)).label("vote_count"),
        )
        .join(Team, Team.id == Vote.team_id)
        .group_by(Vote.team_id, Team.name)
    ).all()

    total_score = sum(r.total_score or 0 for r in rows)
    total_votes = sum(r.vote_count or 0 for r in rows)
    overall_mean = total_score / total_votes if total_votes else 0

    scored = []
    for r in rows:
        votes = r.vote_count or 0
        raw_average = (r.total_score or 0) / votes if votes else 0
        adjusted = (votes * raw_average + BAYES_PRIOR_WEIGHT * overall_mean) / (votes + BAYES_PRIOR_WEIGHT)
        scored.append((r.team_id, r.team_name, round(adjusted, 4), round(raw_average, 4), votes))

    scored.sort(key=lambda s: s[2], reverse=True)
    return [TeamRanking(rank, *s) for rank, s in enumerate(scored, start=1)]
