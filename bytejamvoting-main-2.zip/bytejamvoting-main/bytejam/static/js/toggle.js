// Shared page behaviour:
//  - [data-toggle-panel="id"] buttons show/hide the element with that id.
//  - forms with [data-confirm="message"] ask before submitting (used for destructive admin actions).
document.addEventListener("click", (event) => {
  const trigger = event.target.closest("[data-toggle-panel]");
  if (!trigger) return;

  const panel = document.getElementById(trigger.dataset.togglePanel);
  if (!panel) return;
  const nowHidden = panel.classList.toggle("hidden");
  trigger.setAttribute("aria-expanded", String(!nowHidden));
});

document.addEventListener("submit", (event) => {
  const message = event.target.dataset.confirm;
  if (message && !window.confirm(message)) event.preventDefault();
});
