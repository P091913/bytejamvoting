// Admin panel tabs. The active tab is remembered so you land back on it after submitting a form.
(function () {
  const STORAGE_KEY = "bytejam-admin-tab";
  const ACTIVE_CLASSES = ["bg-white/10", "text-white"];
  const tabs = document.querySelectorAll(".tab");

  function rememberTab(name) {
    try { sessionStorage.setItem(STORAGE_KEY, name); } catch (e) { /* storage unavailable */ }
  }

  function savedTab() {
    try { return sessionStorage.getItem(STORAGE_KEY); } catch (e) { return null; }
  }

  function showTab(name) {
    if (!document.getElementById(name + "-section")) name = "companies";

    document.querySelectorAll(".tab-section").forEach((section) => {
      section.classList.toggle("hidden", section.id !== name + "-section");
    });
    tabs.forEach((tab) => {
      const active = tab.dataset.tab === name;
      ACTIVE_CLASSES.forEach((cls) => tab.classList.toggle(cls, active));
      tab.classList.toggle("text-white/70", !active);
      tab.setAttribute("aria-selected", String(active));
    });
    rememberTab(name);
  }

  tabs.forEach((tab) => tab.addEventListener("click", () => showTab(tab.dataset.tab)));
  showTab(savedTab() || "companies");
})();
