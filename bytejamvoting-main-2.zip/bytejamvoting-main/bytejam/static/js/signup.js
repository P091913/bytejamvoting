// Sign-up page: show the guest or member fields depending on the selected role.
(function () {
  const roleSelect = document.getElementById("role");
  const userType = document.getElementById("user_type");
  const panels = {
    guest: document.getElementById("guest-fields"),
    member: document.getElementById("member-fields"),
  };

  function setRequired(panel, isRequired) {
    panel.querySelectorAll("input:not([readonly])").forEach((field) => {
      field.required = isRequired;
    });
  }

  function showPanelFor(role) {
    Object.entries(panels).forEach(([name, panel]) => {
      const active = name === role;
      panel.classList.toggle("hidden", !active);
      setRequired(panel, active);
    });

    const active = panels[role];
    userType.value = active ? active.dataset.userType : "";
    if (active) active.querySelector("input:not([readonly])").focus();
  }

  roleSelect.addEventListener("change", () => showPanelFor(roleSelect.value));
})();
