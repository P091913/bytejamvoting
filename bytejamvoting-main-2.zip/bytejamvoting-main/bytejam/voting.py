"""Voting rules: who votes on what, when voting is open, and recording ballots."""
from dataclasses import dataclass
from datetime import datetime
from zoneinfo import ZoneInfo

from flask import current_app
from sqlalchemy.exc import IntegrityError

from .extensions import db
from .models import DIVISIONS, Team, User, Vote, VotingSettings

MIN_SCORE = 0
MAX_SCORE = 5

STUDENT_CATEGORIES = ("Amazement", "Theme", "Performance")
DEFAULT_CATEGORIES = ("Creativity", "Visual Design", "Professionalism", "Communication", "Performance")

# A Bits/Bytes coach may only judge the other division.
OPPOSITE_DIVISION = {"Bits": "Bytes", "Bytes": "Bits"}


class VotingError(Exception):
    """A ballot was rejected; the message is safe to show to the voter."""


@dataclass(frozen=True)
class Category:
    label: str  # stored in Vote.category

    @property
    def field(self) -> str:  # form field name, e.g. "Visual Design" -> "visualdesign"
        return self.label.lower().replace(" ", "")


def categories_for(user: User) -> list[Category]:
    labels = STUDENT_CATEGORIES if user.role == "student" else DEFAULT_CATEGORIES
    return [Category(label) for label in labels]


def allowed_divisions(user: User) -> tuple[str, ...]:
    """Divisions whose teams this user may vote for."""
    team_division = user.team.division if user.team else None

    if user.role == "company":
        return ("IHCC",)
    if user.role == "coach" and team_division in OPPOSITE_DIVISION:
        return (OPPOSITE_DIVISION[team_division],)
    if user.role == "student" and team_division == "IHCC":
        return ("Bits", "Bytes")
    return DIVISIONS


# ---------- Voting window ----------

def current_settings() -> VotingSettings | None:
    return db.session.scalars(db.select(VotingSettings).order_by(VotingSettings.id.desc())).first()


def now() -> datetime:
    """Current time as a naive datetime in the timezone voting windows are entered in."""
    tz_name = current_app.config.get("VOTING_TIMEZONE")
    if tz_name:
        return datetime.now(ZoneInfo(tz_name)).replace(tzinfo=None)
    return datetime.now()


def voting_is_open(settings: VotingSettings | None = None) -> bool:
    settings = settings or current_settings()
    return bool(settings) and settings.voting_start <= now() <= settings.voting_end


def save_voting_window(start: datetime, end: datetime) -> VotingSettings:
    if start >= end:
        raise VotingError("Voting start must be before voting end.")
    settings = VotingSettings(voting_start=start, voting_end=end)
    db.session.add(settings)
    db.session.commit()
    return settings


# ---------- Ballots ----------

def teams_by_division(divisions: tuple[str, ...] = DIVISIONS) -> dict[str, list[Team]]:
    """Teams grouped by division, in DIVISIONS order; empty divisions are left out."""
    teams = db.session.scalars(
        db.select(Team).where(Team.division.in_(divisions)).order_by(Team.id)
    ).all()
    grouped = {division: [] for division in DIVISIONS if division in divisions}
    for team in teams:
        grouped[team.division].append(team)
    return {division: teams for division, teams in grouped.items() if teams}


def voted_team_ids(user: User) -> set[int]:
    return set(db.session.scalars(db.select(Vote.team_id).where(Vote.user_id == user.id).distinct()))


def parse_scores(user: User, form) -> dict[str, int]:
    """Validate the submitted scores and return {category label: score}."""
    scores = {}
    for category in categories_for(user):
        raw = (form.get(category.field) or "").strip()
        if not raw:
            raise VotingError("All score fields are required.")
        try:
            value = int(raw)
        except ValueError:
            raise VotingError("Scores must be whole numbers.") from None
        if not MIN_SCORE <= value <= MAX_SCORE:
            raise VotingError(f"Scores must be between {MIN_SCORE} and {MAX_SCORE}.")
        scores[category.label] = value
    return scores


def cast_votes(user: User, team_name: str, form) -> Team:
    if not voting_is_open():
        raise VotingError("Voting is not open right now.")

    team = db.session.scalars(db.select(Team).filter_by(name=team_name)).first()
    if not team:
        raise VotingError("Invalid team name.")
    if team.division not in allowed_divisions(user):
        raise VotingError(f"You can't vote for teams in the {team.division} division.")
    if team.id in voted_team_ids(user):
        raise VotingError(f"You have already voted for {team.name}.")

    scores = parse_scores(user, form)
    db.session.add_all(
        Vote(team_id=team.id, user_id=user.id, category=category, score=score)
        for category, score in scores.items()
    )
    try:
        db.session.commit()
    except IntegrityError:
        # The unique constraint caught a double-submit that raced past the check above.
        db.session.rollback()
        raise VotingError(f"You have already voted for {team.name}.") from None
    return team
