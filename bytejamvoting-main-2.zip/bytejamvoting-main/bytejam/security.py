"""Access control: the IP allowlist, admin authentication and safe redirects."""
import hmac
import ipaddress
from functools import wraps
from urllib.parse import urlparse

from flask import abort, current_app, flash, redirect, request, session, url_for

# Reachable from any IP so an admin can still sign in.
PUBLIC_PATH_PREFIXES = ("/admin-login", "/static/")


def client_ip() -> str:
    # ProxyFix (configured in create_app) has already resolved the real client address
    # from X-Forwarded-For using only the trusted proxy hops, so it can't be spoofed.
    return request.remote_addr or ""


def ip_allowed(ip: str) -> bool:
    if current_app.config["ALLOW_ALL"]:
        return True
    if not ip:
        return False

    for allowed in current_app.config["ALLOWED_CONN"]:
        if "/" in allowed:
            try:
                if ipaddress.ip_address(ip) in ipaddress.ip_network(allowed, strict=False):
                    return True
            except ValueError:
                continue
        # Exact match, or a prefix such as "167.142." for a whole range.
        elif ip == allowed or ip.startswith(allowed):
            return True
    return False


def enforce_ip_allowlist():
    """before_request hook: reject clients outside the allowlist."""
    if request.path.startswith(PUBLIC_PATH_PREFIXES):
        return None
    if not ip_allowed(client_ip()):
        abort(403)
    return None


def verify_admin(username: str, password: str) -> bool:
    expected_password = current_app.config["ADMIN_PASSWORD"]
    if not expected_password:
        current_app.logger.warning("ADMIN_PASSWORD is not set; admin login is disabled.")
        return False
    username_ok = hmac.compare_digest(username.encode(), current_app.config["ADMIN_USERNAME"].encode())
    password_ok = hmac.compare_digest(password.encode(), expected_password.encode())
    return username_ok and password_ok


def admin_required(view_func):
    @wraps(view_func)
    def wrapper(*args, **kwargs):
        if not session.get("is_admin"):
            flash("Admin login required.", "warning")
            return redirect(url_for("admin.login", next=request.path))
        return view_func(*args, **kwargs)
    return wrapper


def safe_next_url(target: str | None, fallback: str) -> str:
    """Only allow redirects to local paths, so ?next= can't send the admin to another site."""
    if not target:
        return fallback
    parsed = urlparse(target)
    if parsed.scheme or parsed.netloc or not target.startswith("/") or target.startswith("//"):
        return fallback
    return target
