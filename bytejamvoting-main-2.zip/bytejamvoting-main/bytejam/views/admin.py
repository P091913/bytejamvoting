"""Admin pages: login, the admin panel, roster management, voting window and data reset."""
from datetime import datetime

from flask import Blueprint, current_app, flash, redirect, render_template, request, session, url_for
from sqlalchemy.orm import selectinload

from .. import roster, voting
from ..extensions import db
from ..models import DIVISIONS, Company
from ..scoring import compute_rankings
from ..security import admin_required, client_ip, safe_next_url, verify_admin

bp = Blueprint("admin", __name__)

DATETIME_LOCAL_FORMAT = "%Y-%m-%dT%H:%M"  # what <input type="datetime-local"> submits


def _field(name: str) -> str:
    return (request.form.get(name) or "").strip()


# (entity type, action) -> handler. Every handler returns a success message or raises RosterError.
ROSTER_ACTIONS = {
    ("company", "add"): lambda: roster.add_company(_field("company_name")),
    ("company", "remove"): lambda: roster.remove_company(_field("company_id")),
    ("company", "add_member"): lambda: roster.add_company_member(
        _field("company_id"), _field("first_name"), _field("last_name"), client_ip()),
    ("company", "remove_member"): lambda: roster.remove_member(_field("user_id")),
    ("team", "add"): lambda: roster.add_team(_field("team_name"), _field("division")),
    ("team", "remove"): lambda: roster.remove_team(_field("team_id")),
    ("team", "add_member"): lambda: roster.add_team_member(
        _field("team_id"), _field("first_name"), _field("last_name"), _field("role"), client_ip()),
    ("team", "remove_member"): lambda: roster.remove_member(_field("user_id")),
}


@bp.route("/admin-login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if verify_admin(_field("username"), request.form.get("password") or ""):
            session["is_admin"] = True
            flash("Welcome, admin.", "success")
            return redirect(safe_next_url(request.args.get("next"), url_for("admin.panel")))
        flash("Invalid admin credentials.", "danger")
    return render_template("admin_login.html")


@bp.route("/admin-logout")
def logout():
    session.pop("is_admin", None)
    flash("Logged out.", "info")
    return redirect(url_for("admin.login"))


@bp.route("/admin")
@admin_required
def panel():
    companies = db.session.scalars(
        db.select(Company).options(selectinload(Company.users)).order_by(Company.id)
    ).all()
    settings = voting.current_settings()
    return render_template(
        "admin.html",
        companies=companies,
        teams=voting.teams_by_division(),
        divisions=DIVISIONS,
        rankings=compute_rankings(),
        settings=settings,
        voting_open=voting.voting_is_open(settings),
        datetime_format=DATETIME_LOCAL_FORMAT,
    )


@bp.route("/submit", methods=["POST"])
@admin_required
def handle_form():
    handler = ROSTER_ACTIONS.get((request.form.get("type"), request.form.get("action")))
    if handler is None:
        flash("Unknown admin action.", "danger")
        return redirect(url_for("admin.panel"))

    try:
        flash(handler(), "success")
    except roster.RosterError as e:
        db.session.rollback()
        flash(str(e), "danger")
    except Exception:
        db.session.rollback()
        current_app.logger.exception("Error handling admin submit")
        flash("An error occurred processing your request.", "danger")
    return redirect(url_for("admin.panel"))


@bp.route("/save_voting_settings", methods=["POST"])
@admin_required
def save_voting_settings():
    start, end = _field("voting_start"), _field("voting_end")
    if not (start and end):
        flash("Both start and end times are required.", "danger")
        return redirect(url_for("admin.panel"))

    try:
        voting.save_voting_window(
            datetime.strptime(start, DATETIME_LOCAL_FORMAT),
            datetime.strptime(end, DATETIME_LOCAL_FORMAT),
        )
    except ValueError:
        flash("Invalid date format. Use the date-time picker.", "danger")
    except voting.VotingError as e:
        flash(str(e), "danger")
    else:
        flash("Voting window saved.", "success")
    return redirect(url_for("admin.panel"))


@bp.route("/delete_data", methods=["POST"])
@admin_required
def delete_data():
    try:
        message = roster.clear_data(
            votes="delete_votes" in request.form,
            users="delete_users" in request.form,
            teams="delete_teams" in request.form,
            companies="delete_companies" in request.form,
        )
        flash(message, "success")
    except roster.RosterError as e:
        flash(str(e), "warning")
    except Exception:
        db.session.rollback()
        current_app.logger.exception("Error deleting data")
        flash("There was an error deleting data.", "danger")
    return redirect(url_for("admin.panel"))
