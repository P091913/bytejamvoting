"""Voter-facing pages: sign in, the voting dashboard and ballot submission."""
from flask import Blueprint, current_app, flash, redirect, render_template, request, url_for

from .. import voting
from ..accounts import AccountError, current_user, find_member, log_in, register_guest
from ..extensions import db
from ..pins import generate_pin
from ..scoring import compute_rankings
from ..security import client_ip

bp = Blueprint("voter", __name__)

USER_TYPE_MEMBER = "1"
USER_TYPE_GUEST = "2"


def _field(name: str) -> str:
    return (request.form.get(name) or "").strip()


@bp.route("/create")
def create():
    return render_template("index.html", fresh_pin=generate_pin())


@bp.route("/register_user", methods=["POST"])
def register_user():
    user_type = request.form.get("user_type")
    try:
        if user_type == USER_TYPE_MEMBER:
            user = find_member(_field("m_first_name"), _field("m_last_name"), _field("company_pin"))
            message = "Welcome back!"
        elif user_type == USER_TYPE_GUEST:
            user = register_guest(_field("first_name"), _field("last_name"), _field("pin"), client_ip())
            message = "Guest registered."
        else:
            raise AccountError("Invalid user type selected!")
    except AccountError as e:
        flash(str(e), "danger")
        return redirect(url_for("voter.create"))
    except Exception:
        db.session.rollback()
        current_app.logger.exception("Error registering user")
        flash("Could not sign you in. Contact admin.", "danger")
        return redirect(url_for("voter.create"))

    log_in(user)
    flash(message, "success")
    return redirect(url_for("voter.dashboard"))


@bp.route("/")
def dashboard():
    settings = voting.current_settings()
    if not settings:
        flash("Voting settings have not been configured yet.", "warning")
        return redirect(url_for("voter.not_allowed"))
    if not voting.voting_is_open(settings):
        return redirect(url_for("voter.not_allowed"))

    user = current_user()
    if not user:
        flash("You must be logged in to view the dashboard.", "warning")
        return redirect(url_for("voter.create"))

    show_leaderboard = current_app.config["PUBLIC_LEADERBOARD"]
    return render_template(
        "dashboard.html",
        user=user,
        teams=voting.teams_by_division(voting.allowed_divisions(user)),
        voted_team_ids=voting.voted_team_ids(user),
        categories=voting.categories_for(user),
        score_range=range(voting.MIN_SCORE, voting.MAX_SCORE + 1),
        show_leaderboard=show_leaderboard,
        rankings=compute_rankings() if show_leaderboard else [],
    )


@bp.route("/submit_vote", methods=["POST"])
def submit_vote():
    user = current_user()
    if not user:
        flash("You must be logged in to vote.", "danger")
        return redirect(url_for("voter.create"))

    try:
        team = voting.cast_votes(user, _field("team"), request.form)
    except voting.VotingError as e:
        flash(str(e), "danger")
    except Exception:
        db.session.rollback()
        current_app.logger.exception("Error saving votes")
        flash("There was an error saving your vote. Please try again.", "danger")
    else:
        flash(f"Your vote for {team.name} has been submitted!", "success")
    return redirect(url_for("voter.dashboard"))


@bp.route("/not_allowed")
def not_allowed():
    return render_template("not_allowed.html", settings=voting.current_settings())
