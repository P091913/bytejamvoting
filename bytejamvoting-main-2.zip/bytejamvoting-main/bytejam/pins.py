import secrets
import string

PIN_LENGTH = 4


def generate_pin(length: int = PIN_LENGTH) -> str:
    # PINs act as login credentials, so use a cryptographic RNG.
    return "".join(secrets.choice(string.digits) for _ in range(length))


def is_valid_pin(pin: str) -> bool:
    return pin.isdigit() and len(pin) == PIN_LENGTH
