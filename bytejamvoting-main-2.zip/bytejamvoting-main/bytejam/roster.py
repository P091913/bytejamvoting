"""Admin management of companies, teams and their members.

Each action returns a success message for the admin, or raises RosterError.
"""
from sqlalchemy import delete, or_, select, true

from .extensions import db
from .models import DIVISIONS, Company, Team, User, Vote
from .pins import generate_pin

TEAM_ROLES = ("student", "coach")


class RosterError(Exception):
    """An admin action was rejected; the message is safe to show to the admin."""


def _get(model, raw_id, label: str):
    try:
        obj = db.session.get(model, int(raw_id))
    except (TypeError, ValueError):
        obj = None
    if obj is None:
        raise RosterError(f"{label} not found!")
    return obj


def _name_taken(model, name: str) -> bool:
    return db.session.scalars(select(model).filter_by(name=name)).first() is not None


# ---------- Companies ----------

def add_company(name: str) -> str:
    if not name:
        raise RosterError("Company name is required.")
    if _name_taken(Company, name):
        raise RosterError(f"Company '{name}' already exists.")
    db.session.add(Company(name=name, pin=generate_pin()))
    db.session.commit()
    return f"Company '{name}' added successfully!"


def remove_company(company_id) -> str:
    company = _get(Company, company_id, "Company")
    db.session.delete(company)  # cascades to its members and their votes
    db.session.commit()
    return f"Company '{company.name}' removed successfully!"


def add_company_member(company_id, first_name: str, last_name: str, ip_address: str) -> str:
    if not (first_name and last_name):
        raise RosterError("Member name is required.")
    company = _get(Company, company_id, "Company")
    db.session.add(User(
        role="company", first_name=first_name, last_name=last_name,
        pin=company.pin, company_id=company.id, ip_address=ip_address,
    ))
    db.session.commit()
    return f"Member '{first_name} {last_name}' added to '{company.name}'!"


# ---------- Teams ----------

def add_team(name: str, division: str) -> str:
    if not (name and division):
        raise RosterError("Team name and division are required.")
    if division not in DIVISIONS:
        raise RosterError(f"Unknown division '{division}'.")
    if _name_taken(Team, name):
        raise RosterError(f"Team '{name}' already exists.")
    db.session.add(Team(name=name, division=division))
    db.session.commit()
    return f"Team '{name}' added successfully!"


def remove_team(team_id) -> str:
    team = _get(Team, team_id, "Team")
    db.session.delete(team)  # cascades to its members and all votes for/by them
    db.session.commit()
    return f"Team '{team.name}' removed successfully!"


def add_team_member(team_id, first_name: str, last_name: str, role: str, ip_address: str) -> str:
    if not (first_name and last_name):
        raise RosterError("Member name and team are required.")
    team = _get(Team, team_id, "Team")
    role = role if role in TEAM_ROLES else "student"
    user = User(
        role=role, first_name=first_name, last_name=last_name,
        pin=generate_pin(), team_id=team.id, ip_address=ip_address,
    )
    db.session.add(user)
    db.session.commit()
    return f"{role.capitalize()} '{user.full_name}' added to '{team.name}' with PIN {user.pin}!"


# ---------- Members (company or team) ----------

def remove_member(user_id) -> str:
    user = _get(User, user_id, "Member")
    db.session.delete(user)  # cascades to their votes
    db.session.commit()
    return f"Member '{user.full_name}' removed!"


# ---------- Bulk clear ----------

def clear_data(*, votes: bool = False, users: bool = False, teams: bool = False, companies: bool = False) -> str:
    """Bulk-delete the selected tables, plus whatever depends on them.

    - users: also deletes all votes
    - teams: also deletes all votes and every team member
    - companies: also deletes every company member and their votes
    """
    if not any((votes, users, teams, companies)):
        raise RosterError("Select at least one kind of data to delete.")

    if users:
        doomed_users = true()
    else:
        conditions = []
        if teams:
            conditions.append(User.team_id.is_not(None))
        if companies:
            conditions.append(User.company_id.is_not(None))
        doomed_users = or_(*conditions) if conditions else None

    # Every vote references both a user and a team, so deleting either clears them all.
    if votes or users or teams:
        db.session.execute(delete(Vote))
    elif doomed_users is not None:
        db.session.execute(delete(Vote).where(Vote.user_id.in_(select(User.id).where(doomed_users))))

    if doomed_users is not None:
        db.session.execute(delete(User).where(doomed_users))
    if teams:
        db.session.execute(delete(Team))
    if companies:
        db.session.execute(delete(Company))

    db.session.commit()
    return "Requested data deleted."
