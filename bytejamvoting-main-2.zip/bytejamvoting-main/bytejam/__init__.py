"""ByteJam voting app."""
from flask import Flask, flash, redirect, request, url_for
from flask_wtf.csrf import CSRFError
from werkzeug.middleware.proxy_fix import ProxyFix

from .config import Config
from .extensions import csrf, db
from .security import enforce_ip_allowlist
from .views import admin, voter


def create_app(overrides: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.from_object(Config)
    if overrides:
        app.config.update(overrides)

    if not app.config["SQLALCHEMY_DATABASE_URI"]:
        raise RuntimeError("DATABASE_URL is not set. Copy .env.example to .env and fill it in.")
    if not app.config["SECRET_KEY_FROM_ENV"] and not app.testing:
        app.logger.warning("FLASK_SECRET_KEY is not set; sessions will reset on every restart.")

    if app.config["TRUSTED_PROXIES"]:
        proxies = app.config["TRUSTED_PROXIES"]
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=proxies, x_proto=proxies, x_host=proxies)

    db.init_app(app)
    csrf.init_app(app)

    app.before_request(enforce_ip_allowlist)
    app.register_blueprint(voter.bp)
    app.register_blueprint(admin.bp)

    @app.errorhandler(CSRFError)
    def handle_csrf_error(_error):
        flash("Your form expired. Please try again.", "warning")
        return redirect(request.referrer or url_for("voter.create"))

    @app.cli.command("init-db")
    def init_db():
        """Create any missing database tables."""
        db.create_all()
        print("Database tables created.")

    return app
