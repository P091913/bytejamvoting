"""Database models. Table, column and enum names match the original schema."""
from .extensions import db

ROLES = ("student", "guest", "coach", "company")
DIVISIONS = ("Bits", "Bytes", "IHCC")


class Company(db.Model):
    __tablename__ = "company"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), unique=True, nullable=False)
    pin = db.Column(db.String(4), nullable=False)

    users = db.relationship("User", back_populates="company", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Company {self.name}>"


class Team(db.Model):
    __tablename__ = "teams"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), unique=True, nullable=False)
    division = db.Column(db.Enum(*DIVISIONS, name="division_enum"), nullable=False)

    members = db.relationship("User", back_populates="team", cascade="all, delete-orphan")
    votes = db.relationship("Vote", back_populates="team", cascade="all, delete-orphan")

    @property
    def coaches(self):
        return [m for m in self.members if m.role == "coach"]

    @property
    def students(self):
        return [m for m in self.members if m.role == "student"]

    def __repr__(self):
        return f"<Team {self.name}>"


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    role = db.Column(db.Enum(*ROLES, name="role_enum"), nullable=False)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    pin = db.Column(db.String(4), nullable=True)
    company_id = db.Column(db.Integer, db.ForeignKey("company.id"), nullable=True)
    team_id = db.Column(db.Integer, db.ForeignKey("teams.id"), nullable=True)
    ip_address = db.Column(db.String(50), nullable=False)

    company = db.relationship("Company", back_populates="users")
    team = db.relationship("Team", back_populates="members")
    votes = db.relationship("Vote", back_populates="user", cascade="all, delete-orphan")

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

    def __repr__(self):
        return f"<User {self.full_name} ({self.role})>"


class Vote(db.Model):
    __tablename__ = "votes"
    __table_args__ = (db.UniqueConstraint("user_id", "team_id", "category", name="unique_user_vote"),)

    id = db.Column(db.Integer, primary_key=True)
    team_id = db.Column(db.Integer, db.ForeignKey("teams.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    category = db.Column(db.String(50), nullable=True)
    score = db.Column(db.Integer, nullable=True)

    team = db.relationship("Team", back_populates="votes")
    user = db.relationship("User", back_populates="votes")

    def __repr__(self):
        return f"<Vote User {self.user_id} - Team {self.team_id}: {self.category} - {self.score}>"


class VotingSettings(db.Model):
    __tablename__ = "voting_settings"

    id = db.Column(db.Integer, primary_key=True)
    voting_start = db.Column(db.DateTime, nullable=False)
    voting_end = db.Column(db.DateTime, nullable=False)
