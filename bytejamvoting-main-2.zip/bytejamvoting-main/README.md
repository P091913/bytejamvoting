# bytejamvoting

Voting app for the IHCC Byte Jam. Voters sign in as a member (student, coach or company rep) or a guest, then score teams. Admins manage companies, teams and members, set the voting window and see Bayesian-adjusted results.

**New here? See [GETTING_STARTED.md](GETTING_STARTED.md) for step-by-step hosting and event setup.**

## Project layout

```
app.py                  Entry point (gunicorn app:app / python app.py)
bytejam/
  __init__.py           create_app(): wires config, extensions, blueprints, IP guard
  config.py             All settings, read from environment / .env
  extensions.py         SQLAlchemy + CSRF instances
  models.py             Company, Team, User, Vote, VotingSettings
  security.py           IP allowlist, admin auth, safe redirects
  accounts.py           Voter sign-in (members and guests), current user
  voting.py             Voting rules: categories, divisions, voting window, casting ballots
  roster.py             Admin add/remove of companies, teams, members; bulk clear
  scoring.py            Bayesian-average rankings
  pins.py               PIN generation / validation
  views/voter.py        /create, /register_user, /, /submit_vote, /not_allowed
  views/admin.py        /admin-login, /admin-logout, /admin, /submit, /save_voting_settings, /delete_data
  templates/            Jinja templates (all extend base.html)
  static/               styles.css, signup.js, toggle.js, admin.js
tests/                  pytest suite
```

## Voting rules

| Voter | Can vote for | Categories (0–5 each) |
|---|---|---|
| Company rep | IHCC teams | Creativity, Visual Design, Professionalism, Communication, Performance |
| Bits / Bytes coach | The opposite division | same as above |
| IHCC student | Bits and Bytes teams | Amazement, Theme, Performance |
| Other students | All teams | Amazement, Theme, Performance |
| Guest | All teams | Creativity, Visual Design, Professionalism, Communication, Performance |

Each voter can vote for each team once, and only while the voting window is open.

## Running locally

```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements-dev.txt
copy .env.example .env        # then fill it in
python app.py                 # creates tables, starts on http://127.0.0.1:5000
```

For a throwaway local database set `DATABASE_URL=sqlite:///bytejam.db` and `ALLOW_ALL=true`.

Run tests with `pytest`.

## Deploying (Render)

Start command: `gunicorn app:app`. Set the environment variables listed in `.env.example`
(at minimum `DATABASE_URL`, `FLASK_SECRET_KEY`, `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `ALLOWED_CONN`).
Create tables on a new database with `flask --app app init-db`.
