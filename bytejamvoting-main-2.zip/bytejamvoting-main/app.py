"""Entry point. Production: `gunicorn app:app`. Local dev: `python app.py`."""
from bytejam import create_app
from bytejam.extensions import db

app = create_app()

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=app.config["DEBUG"])
