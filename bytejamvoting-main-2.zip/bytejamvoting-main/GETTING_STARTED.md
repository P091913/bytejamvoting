# Getting Started: Hosting ByteJam Voting

This guide takes you from nothing to a live voting site that people can use on event day. You don't need to know Python. Plan on about 30–45 minutes the first time.

The app runs on **[Render](https://render.com)**, a hosting service with a free tier. You will set up two things there:

1. **A database (Postgres)** that stores companies, teams, people and votes.
2. **A web service** that runs the app itself.

---

## What you need

- A **GitHub account**: https://github.com/signup
- A **Render account**: https://dashboard.render.com/register (signing up with GitHub is easiest)
- A copy of this project's code

---

## Step 1: Put the code on GitHub

Render deploys straight from a GitHub repository.

1. On GitHub, click **New repository**. Name it something like `bytejamvoting`, make it **Private**, and click **Create repository**.
2. Upload the project:
   - **Easiest:** on the new repo's page, click **uploading an existing file** and drag in everything in the project folder.
   - **With git:** from the project folder, run:
     ```
     git init
     git add .
     git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/YOUR-USERNAME/bytejamvoting.git
     git push -u origin main
     ```

> ⚠️ **Never upload the `.env` file.** It holds passwords. If you use git, the included `.gitignore` already leaves it out. If you drag and drop, don't include it.

---

## Step 2: Create the database

1. In the Render dashboard, click **New + → Postgres**.
2. Fill in:
   - **Name:** `bytejam-db`
   - **Region:** the one closest to you (e.g. *Ohio* for the Midwest). **Use the same region for the web service in Step 3.**
   - **Instance type:** *Free* is fine for an event.
3. Click **Create Database** and wait until the status says **Available** (a minute or two).
4. On the database page, find **Connections** and copy the **Internal Database URL**. It looks like this:
   ```
   postgresql://bytejam_db_user:abc123...@dpg-xxxxx-a/bytejam_db
   ```
   Keep it handy for the next step.

> 📅 **Free databases expire** after a limited time (30 days at the time of writing), and the data goes with them. Create the database within a few weeks of your event, or upgrade to a paid plan if you need to keep results longer. **Export or screenshot your results before it expires.**

---

## Step 3: Create the web service

1. In Render, click **New + → Web Service**.
2. Choose **Build and deploy from a Git repository** and connect the GitHub repo from Step 1.
3. Fill in these settings:

| Setting | Value |
|---|---|
| **Name** | `bytejam-voting` (this becomes your web address) |
| **Region** | The same region as your database |
| **Branch** | `main` |
| **Runtime** | Python 3 |
| **Build Command** | `pip install -r requirements.txt` |
| **Start Command** | `flask --app app init-db && gunicorn app:app` |
| **Instance Type** | Free works; *Starter* avoids slow wake-ups (see Troubleshooting) |

> The start command creates the database tables the first time. Running it again on later starts is safe: existing data isn't touched.

4. Scroll to **Environment Variables** and add the variables below (see Step 4).
5. Click **Create Web Service**.

---

## Step 4: Set the environment variables

These are the app's settings. In the web service, add each one under **Environment → Add Environment Variable**.

| Key | What to put | Example |
|---|---|---|
| `PYTHON_VERSION` | The Python version to run | `3.12.7` |
| `DATABASE_URL` | The **Internal Database URL** from Step 2 | `postgresql://bytejam_db_user:...` |
| `FLASK_SECRET_KEY` | A long random string (see below) | `9f2c4e...` (64 characters) |
| `ADMIN_USERNAME` | The admin login name you choose | `bytejamadmin` |
| `ADMIN_PASSWORD` | A strong admin password you choose | *(make it strong)* |
| `ALLOW_ALL` | `true` while you set up; `false` on event day | `true` |
| `ALLOWED_CONN` | The venue's public IP address(es); see Step 6 | `167.142.113.82` |
| `TRUSTED_PROXIES` | Always `1` on Render | `1` |
| `VOTING_TIMEZONE` | The timezone you'll enter voting times in | `America/Chicago` |
| `PUBLIC_LEADERBOARD` | `true` shows live rankings to voters | `false` |

**To make a `FLASK_SECRET_KEY`,** run this on any computer with Python:
```
python -c "import secrets; print(secrets.token_hex(32))"
```
Or mash the keyboard for 60+ random letters and numbers. Just don't leave it blank. Without it, people get logged out at random.

After you save, Render redeploys automatically. Watch the **Logs** tab. When you see a line like `Listening at: http://0.0.0.0:10000`, the site is live.

Your site address is shown at the top of the service page, for example `https://bytejam-voting.onrender.com`.

---

## Step 5: Set up your event

Go to **`https://YOUR-SITE.onrender.com/admin-login`** and sign in with the `ADMIN_USERNAME` and `ADMIN_PASSWORD` you chose.

Do the following in the admin panel.

### Companies tab: judges from businesses
1. Type a company name and click **Add**. The company gets a 4-digit **PIN**.
2. Click **Members** next to the company and add each person from that company who will vote.
3. Give each company its PIN. Its people sign in with **their own name + the company PIN**.

### Teams tab: the competing teams
1. Type a team name, pick its division (**Bits**, **Bytes** or **IHCC**) and click **Add**.
2. Click **Members** on a team and add its students and coaches.
3. Each person gets their own PIN, shown in the green message after you add them and next to their name in the list. Hand these out. Students and coaches sign in with **their own name + their personal PIN**.

### Settings tab: when voting is open
1. Set **Voting Start** and **Voting End**, then click **Save Settings**.
2. Voters can only reach the voting page between these times. The tab shows whether voting is currently **Open** or **Closed**.

### Who votes on what (automatic)
| Voter | Sees teams from |
|---|---|
| Company rep | IHCC |
| Bits coach | Bytes |
| Bytes coach | Bits |
| IHCC student | Bits and Bytes |
| Other students, guests | All divisions |

Everyone can vote for each team **once**.

### Do a test run
1. In Settings, set a voting window that includes the current time.
2. Open the site in a **private/incognito window** and go to `https://YOUR-SITE.onrender.com/create`.
3. Sign in as a test person and cast a vote.
4. Check that the vote appears under **Voting Results** in the admin panel.
5. Clean up with **Settings → Clear Data** (check **Delete all votes**), then set the real voting window.

---

## Step 6: Lock it down for event day

By default, the app only lets people on approved networks vote, for example the venue's Wi-Fi. While `ALLOW_ALL` is `true`, anyone on the internet can reach the voting pages.

1. **On the venue's Wi-Fi,** visit https://whatismyipaddress.com and note the **IPv4** address.
2. In Render, set:
   - `ALLOWED_CONN` = that address. Separate several networks with commas, e.g. `167.142.113.82,167.142.113.83`.
   - `ALLOW_ALL` = `false`
3. Save, and let Render redeploy (about a minute).
4. Test from the venue Wi-Fi. Someone on a different network, such as phone data, should get a **403 Forbidden** page.

> 💡 The admin **login page** works from anywhere, but the **admin panel** itself also requires an approved network. Run the event from the venue Wi-Fi, or temporarily set `ALLOW_ALL=true` if you need admin access from elsewhere.

> 💡 If voters use phone data instead of Wi-Fi, they'll be blocked. Tell everyone to join the venue Wi-Fi, or leave `ALLOW_ALL=true` and rely on PINs alone.

---

## Step 7: After the event

1. Open **Voting Results** in the admin panel. Teams are ranked by an **adjusted score** that keeps a team with only a few votes from jumping to the top or bottom. **Raw Avg** and **Votes** are shown too.
2. **Screenshot or copy the results.** There's no export button.
3. To reuse the site next year, use **Settings → Clear Data** to wipe votes, users, teams and/or companies.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| **403 Forbidden** | The device isn't on an allowed network. Check `ALLOWED_CONN` (Step 6), or set `ALLOW_ALL=true`. |
| **"Voting is not allowed at this time."** | The voting window isn't open. Check the **Settings** tab. If the times look right but it's still closed, set `VOTING_TIMEZONE` (e.g. `America/Chicago`); Render's clock runs on UTC. |
| **Admin login says invalid credentials** | Check `ADMIN_USERNAME` / `ADMIN_PASSWORD` in Render for typos and extra spaces. |
| **People get logged out randomly** | `FLASK_SECRET_KEY` is missing. Set it (Step 4). |
| **"User not found" when signing in** | The name must match exactly what the admin entered, with the right PIN: the company PIN for company reps, the personal PIN for students and coaches. |
| **First page load takes ~1 minute** | Free Render services sleep after 15 minutes without traffic. Open the site a few minutes before the event starts, or use a paid instance type. |
| **Deploy fails with `DATABASE_URL is not set`** | Add the `DATABASE_URL` variable (Step 4). |
| **Deploy fails connecting to the database** | Make sure you used the **Internal** Database URL and that the database and web service are in the **same region**. |
| **Something else** | Check the **Logs** tab on the web service in Render. Errors show up there. |

---

## Running it on your own computer (optional)

To try the app locally before hosting it, see the **Running locally** section of [README.md](README.md).
